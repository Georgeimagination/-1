/*************************************************************************
 * Copyright (C) [2022] by Cambricon, Inc.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
 * CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *************************************************************************/
#include "focal_loss_sigmoid.h"

#include <string>

#include "core/context.h"
#include "core/gen_case.h"
#include "core/logging.h"
#include "core/runtime/device.h"
#include "core/tensor.h"
#include "core/type.h"
#include "kernels/kernel.h"
#include "mlu_op.h"

static void policyFunc(const mluOpHandle_t handle, cnrtDim3_t *k_dim,
                       cnrtFunctionType_t *k_type) {
  *k_type = cnrtFuncTypeUnion1;
  k_dim->x = handle->core_num_per_cluster;
  k_dim->y = mluop::runtime::getClusterLimitCapability(handle);
  k_dim->z = 1;
}

/*
 * FocalLossSigmoidForwrad
 */
static mluOpStatus_t checkFocalLossSigmoidForwardValidation(
    const mluOpTensorDescriptor_t input_desc,
    const mluOpTensorDescriptor_t target_desc,
    const mluOpTensorDescriptor_t weight_desc,
    const mluOpTensorDescriptor_t output_desc) {
  const std::string interface_name = "[mluOpFocalLossSigmoidForward] ";
  const mluOpDataType_t input_dtype = input_desc->getDtype();
  const mluOpDataType_t target_dtype = target_desc->getDtype();
  const mluOpDataType_t output_dtype = output_desc->getDtype();

  // check shape
  if (input_desc->getDim() != 2) {
    LOG(ERROR) << interface_name << "Dimension num of input should be 2. "
               << "But now it is " << input_desc->getDim() << ".";
    return MLUOP_STATUS_BAD_PARAM;
  }
  if (target_desc->getDim() != 1) {
    LOG(ERROR) << interface_name << "Dimension num of target should be 1. "
               << "But now it is " << target_desc->getDim() << ".";
    return MLUOP_STATUS_BAD_PARAM;
  }
  if (target_desc->getDimIndex(0) != input_desc->getDimIndex(0)) {
    LOG(ERROR) << interface_name << "Element num of target should be "
               << input_desc->getDimIndex(0) << ", But now it is "
               << target_desc->getDimIndex(0) << ".";
    return MLUOP_STATUS_BAD_PARAM;
  }
  if (output_desc->getDim() != 2) {
    LOG(ERROR) << interface_name << "Dimension num of output should be 2. "
               << "But now it is " << output_desc->getDim() << ".";
    return MLUOP_STATUS_BAD_PARAM;
  }
  if (output_desc->getDimIndex(0) != input_desc->getDimIndex(0) ||
      output_desc->getDimIndex(1) != input_desc->getDimIndex(1)) {
    LOG(ERROR) << interface_name << "Shape of output and input must be euqal. "
               << "But now output.shape is [" << output_desc->getDimIndex(0)
               << ", " << output_desc->getDimIndex(1) << "], "
               << "and input.shape is [" << input_desc->getDimIndex(0) << ", "
               << input_desc->getDimIndex(1) << "]. ";
    return MLUOP_STATUS_BAD_PARAM;
  }

  // check dtype
  if (input_dtype != MLUOP_DTYPE_FLOAT && input_dtype != MLUOP_DTYPE_HALF) {
    LOG(ERROR) << interface_name
               << "Data type of input should be HALF or FLOAT. "
               << "But now it is " << mluOpGetNameOfDataType(input_dtype)
               << ".";
    return MLUOP_STATUS_BAD_PARAM;
  }
  if (target_dtype != MLUOP_DTYPE_INT32) {
    LOG(ERROR) << interface_name << "Data type of target should be INT32. "
               << "But now it is " << mluOpGetNameOfDataType(target_dtype)
               << ".";
    return MLUOP_STATUS_BAD_PARAM;
  }
  if (output_dtype != input_dtype) {
    LOG(ERROR) << interface_name
               << "Both data types of input and output should be equal. "
               << "But now input_dtype is "
               << mluOpGetNameOfDataType(input_dtype) << ", "
               << "output_dtype is " << mluOpGetNameOfDataType(output_dtype)
               << ".";
    return MLUOP_STATUS_BAD_PARAM;
  }

  // check weight
  if (weight_desc != NULL && mluOpGetTensorElementNum(weight_desc) != 0) {
    if (weight_desc->getDtype() != input_dtype) {
      LOG(ERROR) << interface_name
                 << "Both data types of weight and input should be equal. "
                 << "But now input_dtype is "
                 << mluOpGetNameOfDataType(input_dtype) << ", "
                 << "weight_dtype is "
                 << mluOpGetNameOfDataType(weight_desc->getDtype()) << ".";
      return MLUOP_STATUS_BAD_PARAM;
    }
    if (weight_desc->getDim() != 1) {
      LOG(ERROR) << interface_name << "Dimension num of weight should be 1. "
                 << "But now it is " << weight_desc->getDim() << ".";
      return MLUOP_STATUS_BAD_PARAM;
    }
    if (weight_desc->getDimIndex(0) != input_desc->getDimIndex(1)) {
      LOG(ERROR) << interface_name << "Element num of weight should be "
                 << input_desc->getDimIndex(1) << ", But now it is "
                 << weight_desc->getDimIndex(0) << ".";
      return MLUOP_STATUS_BAD_PARAM;
    }
  } else {
    VLOG(5) << interface_name << "weight is null.";
  }

  // large tensor
  TENSOR_NUM_CHECK("[mluOpFocalLossSigmoidForward]",
                   mluOpGetTensorElementNum(input_desc), LARGE_TENSOR_NUM, "");

  return MLUOP_STATUS_SUCCESS;
}

mluOpStatus_t MLUOP_WIN_API mluOpFocalLossSigmoidForward(
    mluOpHandle_t handle, const mluOpComputationPreference_t prefer,
    const mluOpLossReduction_t reduction,
    const mluOpTensorDescriptor_t input_desc, const void *input,
    const mluOpTensorDescriptor_t target_desc, const void *target,
    const mluOpTensorDescriptor_t weight_desc, const void *weight,
    const float alpha, const float gamma,
    const mluOpTensorDescriptor_t output_desc, void *output) {
  const std::string interface_name = "[mluOpFocalLossSigmoidForward] ";
  PARAM_CHECK("[mluOpFocalLossSigmoidForward]", handle != NULL);
  PARAM_CHECK("[mluOpFocalLossSigmoidForward]", input_desc != NULL);
  PARAM_CHECK("[mluOpFocalLossSigmoidForward]", target_desc != NULL);
  PARAM_CHECK("[mluOpFocalLossSigmoidForward]", output_desc != NULL);

  // params check
  if (prefer ==
      mluOpComputationPreference_t::MLUOP_COMPUTATION_ULTRAHIGH_PRECISION) {
    LOG(ERROR)
        << interface_name
        << "does not support MLUOP_COMPUTATION_ULTRAHIGH_PRECISION currently.";
    return MLUOP_STATUS_NOT_SUPPORTED;
  }
  if (reduction != mluOpLossReduction_t::MLUOP_LOSS_REDUCTION_NONE) {
    LOG(ERROR) << interface_name << "only support REDUCTION_NONE currently.";
    return MLUOP_STATUS_NOT_SUPPORTED;
  }
  if (gamma < 0) {
    LOG(ERROR) << interface_name
               << "gamma should be greater than or equal to 0."
               << "But now gamma is " << gamma << ".";
    return MLUOP_STATUS_NOT_SUPPORTED;
  }
  if (MLUOP_STATUS_SUCCESS !=
      checkFocalLossSigmoidForwardValidation(input_desc, target_desc,
                                             weight_desc, output_desc)) {
    return MLUOP_STATUS_BAD_PARAM;
  }

  if (mluOpGetTensorElementNum(input_desc) == 0 ||
      mluOpGetTensorElementNum(target_desc) == 0 ||
      mluOpGetTensorElementNum(output_desc) == 0) {
    VLOG(5) << interface_name << "Skip zero element tensor.";
    return MLUOP_STATUS_SUCCESS;
  }
  if (weight_desc != NULL && mluOpGetTensorElementNum(weight_desc) != 0) {
    PARAM_CHECK("[mluOpFocalLossSigmoidForward]", weight != NULL);
    STRIDE_TENSOR_CHECK("[mluOpFocalLossSigmoidForward]:", weight_desc,
                        "weight_desc must be contiguous");
  }
  PARAM_CHECK("[mluOpFocalLossSigmoidForward]", input != NULL);
  PARAM_CHECK("[mluOpFocalLossSigmoidForward]", target != NULL);
  PARAM_CHECK("[mluOpFocalLossSigmoidForward]", output != NULL);

  STRIDE_TENSOR_CHECK("[mluOpFocalLossSigmoidForward]:", input_desc,
                      "input_desc must be contiguous");
  STRIDE_TENSOR_CHECK("[mluOpFocalLossSigmoidForward]:", target_desc,
                      "target_desc must be contiguous");
  STRIDE_TENSOR_CHECK("[mluOpFocalLossSigmoidForward]:", output_desc,
                      "output_desc must be contiguous");

  // generate case prototxt.
  const int32_t N = static_cast<int32_t>(input_desc->getDimIndex(0));
  const int32_t C = static_cast<int32_t>(input_desc->getDimIndex(1));

  if (MLUOP_GEN_CASE_ON_NEW) {
    GEN_CASE_START("focal_loss_sigmoid_forward", "FOCAL_LOSS_SIGMOID_FORWARD");
    GEN_CASE_HANDLE(handle);
    GEN_CASE_DATA_REAL(true, "input", input, input_desc);
    if (weight != NULL) {
      GEN_CASE_DATA_REAL_V2(true, "target", target, target_desc, C - 1, 0);
      GEN_CASE_DATA_REAL(true, "weight", weight, weight_desc);
    } else {
      GEN_CASE_DATA_REAL_V2(true, "target", target, target_desc, C, 0);
    }
    GEN_CASE_DATA(false, "output", output, output_desc, 0, 0);
    GEN_CASE_OP_PARAM_SINGLE(0, "focal_loss_sigmoid_forward", "prefer", prefer);
    GEN_CASE_OP_PARAM_SINGLE(1, "focal_loss_sigmoid_forward", "reduction", 0);
    GEN_CASE_OP_PARAM_SINGLE(1, "focal_loss_sigmoid_forward", "alpha", alpha);
    GEN_CASE_OP_PARAM_SINGLE(2, "focal_loss_sigmoid_forward", "gamma", gamma);
    GEN_CASE_TEST_PARAM_NEW(true, true, false, 0.003, 0.003, 0);
  }

  // calculate task dimension
  cnrtDim3_t k_dim;
  cnrtFunctionType_t k_type;
  policyFunc(handle, &k_dim, &k_type);

  // Launch Kernel
  const uint64_t core_dim = handle->core_num_per_cluster;
  VLOG(5) << "Launch Kernel MLUKernelFocalLossSigmoidForward<<<Union"
          << k_type / core_dim << ", " << k_dim.x << ", " << k_dim.y << ", "
          << k_dim.z << ">>>";
  if (input_desc->getDtype() == MLUOP_DTYPE_HALF) {
    CHECK_RETURN("[mluOpBlockKernelFocalLossSigmoidForwardHalf]",
                 mluOpBlockKernelFocalLossSigmoidForwardHalf(
                     k_dim, k_type, handle->queue,
                     static_cast<focalLossSigmoidPreference_t>(prefer), input,
                     target, weight, N, C, alpha, gamma, output));
  } else {
    CHECK_RETURN("[mluOpBlockKernelFocalLossSigmoidForwardFloat]",
                 mluOpBlockKernelFocalLossSigmoidForwardFloat(
                     k_dim, k_type, handle->queue,
                     static_cast<focalLossSigmoidPreference_t>(prefer), input,
                     target, weight, N, C, alpha, gamma, output));
  }

  GEN_CASE_END();
  return MLUOP_STATUS_SUCCESS;
}

/*
 * FocalLossSigmoidBackward
 */
static void getDealNAndThresholdC(const mluOpHandle_t handle,
                                  const int compute_data_bytes,
                                  const int target_data_bytes,
                                  const int total_c, int *deal_n_ptr,
                                  int *threshold_c_ptr, const bool has_weight,
                                  const bool is_half) {
  /* NRAM partition:
   *
   * |-----------------ping pong--------------------|
   * |input | pt | alpha_t | temp | output | target | flt_min | gamma | weight|
   *
   * split_pipeline_num is 5: including input, pt, alpha_t, temp, output.
   */
  const int nram_split_num = 5;
  const int nram_split_pingpong = 2;
  const int max_nram_size = handle->nram_size;
  int compute_align_size = NFU_ALIGN_SIZE;
  if (is_half) {
    compute_align_size += NFU_ALIGN_SIZE;
  }
  const int compute_align_num = compute_align_size / compute_data_bytes;
  // reservered_align_size: including input(ping pong), pt(ping pong),
  //                        alpha_t(ping pong), temp(ping pong),
  //                        output(ping pong), target(ping pong),
  //                        flt_min and gamma.
  const int reservered_align_size =
      ((nram_split_num + 1) * nram_split_pingpong + 2) * compute_align_size;
  int nram_pingpong_size = max_nram_size - reservered_align_size;

  int compute_c = total_c;
  int threshold_c = 0;
  if (has_weight) {
    // reserved space for weight to align
    nram_pingpong_size -= NFU_ALIGN_SIZE;

    // threshold_c * nram_split_pingpong * compute_data_bytes * nram_split_num +
    //     nram_split_pingpong * target_data_bytes +
    //     threshold_c * compute_data_bytes <= nram_pingpong_size
    threshold_c =
        (nram_pingpong_size - nram_split_pingpong * target_data_bytes) /
        (compute_data_bytes * (nram_split_num * nram_split_pingpong + 1));
    threshold_c = PAD_DOWN(threshold_c, compute_align_num);
    int weight_space = PAD_UP(total_c * compute_data_bytes, NFU_ALIGN_SIZE);

    // reserved space for weight
    nram_pingpong_size -= weight_space;
    compute_c = PAD_UP(total_c, compute_align_num);
  } else {
    // threshold_c * nram_split_pingpong * compute_data_bytes * nram_split_num +
    //     nram_split_pingpong * target_data_bytes <= nram_pingpong_size
    threshold_c =
        (nram_pingpong_size / nram_split_pingpong - target_data_bytes) /
        (nram_split_num * compute_data_bytes);
  }
  // deal_n * compute_c * nram_split_pingpong * compute_data_bytes *
  //     nram_split_num + deal_n * nram_split_pingpong * target_data_bytes <=
  //     nram_pingpong_size
  *deal_n_ptr =
      nram_pingpong_size /
      ((nram_split_num * compute_c * compute_data_bytes + target_data_bytes) *
       nram_split_pingpong);
  *threshold_c_ptr = threshold_c;
}

static mluOpStatus_t checkParams(const mluOpTensorDescriptor_t input_desc,
                                 const mluOpTensorDescriptor_t target_desc,
                                 const mluOpTensorDescriptor_t weight_desc,
                                 const mluOpTensorDescriptor_t output_desc) {
  const std::string interface_name = "[mluOpFocalLossSigmoidBackward]: ";

  // check shape
  PARAM_CHECK(interface_name, input_desc->getDim() == output_desc->getDim());
  if (input_desc->getDim() != 2) {
    LOG(ERROR) << interface_name << "input_desc->getDim() shoule be 2"
               << "but now input_desc->getDim() is " << input_desc->getDim()
               << ".";
    return MLUOP_STATUS_BAD_PARAM;
  }
  if (target_desc->getDim() != 1) {
    LOG(ERROR) << interface_name << "target_desc->getDim() shoule be 1"
               << "but now target_desc->getDim() is " << target_desc->getDim()
               << ".";
    return MLUOP_STATUS_BAD_PARAM;
  }
  for (int i = 0; i < input_desc->getDim(); ++i) {
    if (input_desc->getDimIndex(i) != output_desc->getDimIndex(i)) {
      LOG(ERROR) << interface_name << "input_desc->dims[" << i
                 << "] should be equal to "
                 << "output_desc->getDimIndex(" << i << "). But now "
                 << "input_desc->getDimIndex(" << i << ") is "
                 << input_desc->getDimIndex(i) << ", "
                 << "output_desc->getDimIndex(" << i << ") is "
                 << output_desc->getDimIndex(i) << ".";
      return MLUOP_STATUS_BAD_PARAM;
    }
  }
  if (input_desc->getDimIndex(0) != target_desc->getDimIndex(0)) {
    LOG(ERROR) << interface_name
               << "input_desc->getDimIndex(0) should be equal to "
               << "target_desc->getDim()[0]. But now "
               << "input_desc->getDimIndex(0) is " << input_desc->getDimIndex(0)
               << ", "
               << "target_desc->getDimIndex(0) is "
               << target_desc->getDimIndex(0) << ".";
    return MLUOP_STATUS_BAD_PARAM;
  }

  // check stride
  STRIDE_TENSOR_CHECK("[mluOpFocalLossSigmoidBackward]:", input_desc,
                      "input_desc must be contiguous");
  STRIDE_TENSOR_CHECK("[mluOpFocalLossSigmoidBackward]:", target_desc,
                      "target_desc must be contiguous");
  STRIDE_TENSOR_CHECK("[mluOpFocalLossSigmoidBackward]:", output_desc,
                      "output_desc must be contiguous");
  if (weight_desc != NULL) {
    STRIDE_TENSOR_CHECK("[mluOpFocalLossSigmoidBackward]:", weight_desc,
                        "weight_desc must be contiguous");
  }

  // check data type
  auto input_dtype = input_desc->getDtype();
  auto target_dtype = target_desc->getDtype();
  PARAM_CHECK(interface_name,
              input_desc->getDtype() == output_desc->getDtype());
  if (input_dtype != MLUOP_DTYPE_FLOAT && input_dtype != MLUOP_DTYPE_HALF) {
    LOG(ERROR) << interface_name << "Types of input should be HALF or FLOAT. "
               << "But now input_dtype is "
               << mluOpGetNameOfDataType(input_dtype) << ".";
    return MLUOP_STATUS_BAD_PARAM;
  }
  if (target_desc->getDtype() != MLUOP_DTYPE_INT32) {
    LOG(ERROR) << interface_name << "The data type of target should be int32, "
               << "but now target dtype is "
               << mluOpGetNameOfDataType(target_dtype) << ".";
    return MLUOP_STATUS_BAD_PARAM;
  }

  // check weight
  if (weight_desc != NULL && mluOpGetTensorElementNum(weight_desc) != 0) {
    if (weight_desc->getDim() != 1) {
      LOG(ERROR) << interface_name << "weight_desc->getDim() shoule be 1"
                 << "but now weight_desc->getDim() is " << weight_desc->getDim()
                 << ".";
      return MLUOP_STATUS_BAD_PARAM;
    }
    if (input_desc->getDimIndex(1) != weight_desc->getDimIndex(0)) {
      LOG(ERROR) << interface_name
                 << "input_desc->getDimIndex(1) should be equal to "
                 << "weight_desc->getDimIndex(0). But now "
                 << "input_desc->getDimIndex(1) is "
                 << input_desc->getDimIndex(1) << ", "
                 << "weight_desc->getDimIndex(0) is "
                 << weight_desc->getDimIndex(0) << ".";
      return MLUOP_STATUS_BAD_PARAM;
    }
    if (weight_desc->getDtype() != input_dtype) {
      LOG(ERROR) << interface_name
                 << "Both types of weight and output should be equal. "
                 << "But now input_dtype is "
                 << mluOpGetNameOfDataType(input_dtype) << ", "
                 << "weight_dtype is "
                 << mluOpGetNameOfDataType(weight_desc->getDtype()) << ".";
      return MLUOP_STATUS_BAD_PARAM;
    }
  } else {
    VLOG(5) << interface_name << "weight is NULL.";
  }

  return MLUOP_STATUS_SUCCESS;
}

mluOpStatus_t MLUOP_WIN_API mluOpFocalLossSigmoidBackward(
    mluOpHandle_t handle, const mluOpComputationPreference_t prefer,
    const mluOpLossReduction_t reduction,
    const mluOpTensorDescriptor_t input_desc, const void *input,
    const mluOpTensorDescriptor_t target_desc, const void *target,
    const mluOpTensorDescriptor_t weight_desc, const void *weight,
    const float alpha, const float gamma,
    const mluOpTensorDescriptor_t output_desc, void *output) {
  const std::string interface_name = "[mluOpFocalLossSigmoidBackward]: ";
  // params check
  PARAM_CHECK(interface_name, handle != NULL);
  PARAM_CHECK(interface_name, input_desc != NULL);
  PARAM_CHECK(interface_name, target_desc != NULL);
  PARAM_CHECK(interface_name, output_desc != NULL);

  if (checkParams(input_desc, target_desc, weight_desc, output_desc) !=
      MLUOP_STATUS_SUCCESS) {
    return MLUOP_STATUS_BAD_PARAM;
  }
  if (prefer !=
      mluOpComputationPreference_t::MLUOP_COMPUTATION_HIGH_PRECISION) {
    LOG(ERROR) << interface_name << "only surpport HIGH_PRECISION currently.";
    return MLUOP_STATUS_NOT_SUPPORTED;
  }
  if (reduction != mluOpLossReduction_t::MLUOP_LOSS_REDUCTION_NONE) {
    LOG(ERROR) << interface_name << "only surpport REDUCTION_NONE currently.";
    return MLUOP_STATUS_NOT_SUPPORTED;
  }

  if (gamma < 0 || gamma > 10000) {
    LOG(ERROR) << interface_name
               << "gamma should be in the range of [0, 10000]. "
               << "But now gamma is " << gamma << ".";
    return MLUOP_STATUS_NOT_SUPPORTED;
  }

  bool has_weight = false;
  if (weight_desc != NULL && mluOpGetTensorElementNum(weight_desc) != 0) {
    has_weight = true;
    PARAM_CHECK(interface_name, weight != NULL);
  }

  int deal_n = 0;
  int compute_data_bytes = sizeof(float);
  int target_data_bytes = mluOpDataTypeBytes(target_desc->getDtype());
  int threshold_c = 0;
  int dim_n = input_desc->getDimIndex(0);
  int dim_c = input_desc->getDimIndex(1);

  bool is_half = input_desc->getDtype() == MLUOP_DTYPE_HALF;
  // calculate deal_n and threshold_c
  getDealNAndThresholdC(handle, compute_data_bytes, target_data_bytes, dim_c,
                        &deal_n, &threshold_c, has_weight, is_half);

#define TO_STRING(dtype) #dtype
#define GET_DTYPE(half_flag) \
  (half_flag ? TO_STRING(MLUOP_DTYPE_HALF) : TO_STRING(MLUOP_DTYPE_FLOAT))

  VLOG(5) << interface_name << "N: " << dim_n << ", C: " << dim_c
          << ", alpha: " << alpha << ", gamma: " << gamma
          << ", dtype: " << GET_DTYPE(is_half)
          << ", has_weight: " << has_weight;
  VLOG(5) << interface_name << "threshold_c: " << threshold_c;
  VLOG(5) << interface_name << "deal_n: " << deal_n;
  // check C
  if (dim_c > threshold_c) {
    LOG(ERROR) << interface_name
               << " input_desc->getDimIndex(1) should be in the range of "
               << "[0, " << threshold_c << "]. "
               << "but now input_desc->getDimIndex(1) is " << dim_c;
    return MLUOP_STATUS_NOT_SUPPORTED;
  }

  size_t input_size = mluOpGetTensorElementNum(input_desc);
  size_t target_size = mluOpGetTensorElementNum(target_desc);
  size_t output_size = mluOpGetTensorElementNum(output_desc);
  if (input_size == 0 || target_size == 0 || output_size == 0) {
    VLOG(5) << interface_name << "skip zero element tensor.";
    return MLUOP_STATUS_SUCCESS;
  }
  PARAM_CHECK(interface_name, input != NULL);
  PARAM_CHECK(interface_name, target != NULL);
  PARAM_CHECK(interface_name, output != NULL);

#define FOCAL_LOSS_GEN_CASE_DATA_REAL(is_input, id, data, data_desc, \
                                      upper_bound, lower_bound)      \
  mluop::gen_case::genCaseData(node, is_input, id, data, data_desc,  \
                               upper_bound, lower_bound, "UNIFORM", true)

  // generate focal_loss_sigmoid_backward prototxt
  if (MLUOP_GEN_CASE_ON_NEW) {
    const int upper_bound = is_half ? 5 : 20;
    const int lower_bound = -1 * upper_bound;
    GEN_CASE_START("focal_loss_sigmoid_backward",
                   "FOCAL_LOSS_SIGMOID_BACKWARD");
    GEN_CASE_HANDLE(handle);
    FOCAL_LOSS_GEN_CASE_DATA_REAL(true, "input", input, input_desc, upper_bound,
                                  lower_bound);
    FOCAL_LOSS_GEN_CASE_DATA_REAL(true, "target", target, target_desc, dim_c,
                                  0);
    if (weight != NULL) {
      FOCAL_LOSS_GEN_CASE_DATA_REAL(true, "weight", weight, weight_desc,
                                    upper_bound, lower_bound);
    }
    GEN_CASE_DATA(false, "output", output, output_desc, 0, 0);
    GEN_CASE_OP_PARAM_SINGLE(0, "focal_loss_sigmoid_backward", "prefer",
                             prefer);
    GEN_CASE_OP_PARAM_SINGLE(1, "focal_loss_sigmoid_backward", "reduction",
                             reduction);
    GEN_CASE_OP_PARAM_SINGLE(1, "focal_loss_sigmoid_backward", "alpha", alpha);
    GEN_CASE_OP_PARAM_SINGLE(2, "focal_loss_sigmoid_backward", "gamma", gamma);
    GEN_CASE_TEST_PARAM_NEW(true, true, false, 0.003, 0.003, 0);
  }

  cnrtDim3_t k_dim;
  cnrtFunctionType_t k_type;
  policyFunc(handle, &k_dim, &k_type);

  VLOG(5) << "Launch Kernel MLUBlockFocalLossSigmoidBackward<<<Union"
          << k_type / CORE_DIM << ", " << k_dim.x << ", " << k_dim.y << ", "
          << k_dim.z << ">>>";
  if (is_half) {
    CHECK_RETURN("[mluOpBlockKernelFocalLossSigmoidBackwardHalf]",
                 mluOpBlockKernelFocalLossSigmoidBackwardHalf(
                     k_dim, k_type, handle->queue, input, target, weight, gamma,
                     alpha, dim_n, deal_n, dim_c, output));
  } else {
    CHECK_RETURN("[mluOpBlockKernelFocalLossSigmoidBackwardFloat]",
                 mluOpBlockKernelFocalLossSigmoidBackwardFloat(
                     k_dim, k_type, handle->queue, input, target, weight, gamma,
                     alpha, dim_n, deal_n, dim_c, output));
  }
  GEN_CASE_END();
  return MLUOP_STATUS_SUCCESS;
}
