#!/usr/bin/env python3
"""Apply this report/card supplement bundle to a local research repository.

No network, subprocess, git commit, or push is performed. The default is a
read-only check. Existing text is retained outside bounded revision blocks.
Requires Python 3.9+ and only the standard library.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import sys
import tempfile
from datetime import datetime, timezone
from typing import Optional

BUNDLE = Path(__file__).resolve().parent
BACKUPS = '.research-revision-backups'


class RevisionError(RuntimeError):
    pass


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def checked_path(root: Path, relative: str) -> Path:
    """Reject traversal, protected repo areas, and symlink-based redirection."""
    p = PurePosixPath(relative)
    if not relative or p.is_absolute() or '..' in p.parts or '\\' in relative:
        raise RevisionError(f'不安全的相对路径：{relative}')
    if p.parts[0] in {'.git', '.github', '99_归档', '补充资料-codex不用管'}:
        raise RevisionError(f'修改包禁止写入此目录：{relative}')
    target = root.joinpath(*p.parts)
    current = root
    for part in p.parts:
        current = current / part
        if current.is_symlink():
            raise RevisionError(f'拒绝通过符号链接写入：{current}')
    if not target.resolve().is_relative_to(root):
        raise RevisionError(f'路径超出仓库：{relative}')
    return target


def make_block(op: dict, newline: str = '\n') -> str:
    content = op['content'].strip('\r\n').replace('\r\n', '\n').replace('\n', newline)
    ident = op['block_id']
    return (f'<!-- BEGIN {ident} -->{newline}' + content +
            f'{newline}<!-- END {ident} -->')


def insert_block(raw: bytes, op: dict) -> bytes:
    try:
        text = raw.decode('utf-8')
    except UnicodeDecodeError as e:
        raise RevisionError(f'{op["path"]} 不是有效UTF-8，停止而不转码。') from e
    newline = '\r\n' if '\r\n' in text else '\n'
    ident = op['block_id']
    begin, end = f'<!-- BEGIN {ident} -->', f'<!-- END {ident} -->'
    n_begin, n_end = text.count(begin), text.count(end)
    block = make_block(op, newline)
    if n_begin or n_end:
        if n_begin != 1 or n_end != 1:
            raise RevisionError(f'{op["path"]} 的修订标识缺失或重复，需人工处理。')
        start = text.index(begin)
        stop = text.index(end, start) + len(end)
        if text[start:stop] != block:
            raise RevisionError(f'{op["path"]} 的本轮增补块已被编辑，拒绝覆盖。')
        return raw
    title = re.search(r'^# [^\r\n]*(?:\r?\n|$)', text, re.MULTILINE)
    if not title:
        raise RevisionError(f'{op["path"]} 无一级标题；拒绝猜测插入位置。')
    pos = title.end()
    # Original text before/after the title stays verbatim.
    return (text[:pos] + newline + block + newline + newline + text[pos:]).encode('utf-8')


def load_plan(root: Path) -> tuple[dict, list[dict]]:
    if not root.is_dir():
        raise RevisionError(f'仓库目录不存在：{root}')
    for required in ('AGENTS.md', '待调研芯片清单.md', '进度记录.md', '调研计划.md'):
        if not checked_path(root, required).is_file():
            raise RevisionError(f'缺少项目恢复入口 {required}，不是已识别的研究仓库副本。')
    manifest = json.loads((BUNDLE / 'manifest.json').read_text(encoding='utf-8'))
    if manifest.get('version') != 1:
        raise RevisionError('不支持的修改包版本。')
    planned, paths = [], set()
    for op in manifest['operations']:
        relative = op['path']
        if relative in paths:
            raise RevisionError(f'重复目标路径：{relative}')
        paths.add(relative)
        target = checked_path(root, relative)
        if not target.is_file():
            raise RevisionError(f'现有资料卡/入口缺失：{relative}；本包不会创建空白原卡。')
        before = target.read_bytes()
        after = insert_block(before, op)
        if after != before:
            planned.append(dict(path=relative, before=before, after=after))
    for entry in manifest['new_files']:
        relative = entry['path']
        if relative in paths:
            raise RevisionError(f'新文件与增补目标重叠：{relative}')
        paths.add(relative)
        src = checked_path(BUNDLE / 'payload', relative)
        if not src.is_file():
            raise RevisionError(f'修改包内容缺失：{relative}')
        after = src.read_bytes()
        if digest(after) != entry['sha256']:
            raise RevisionError(f'修改包内容校验失败：{relative}')
        target = checked_path(root, relative)
        before = target.read_bytes() if target.is_file() else None
        if target.exists() and not target.is_file():
            raise RevisionError(f'新文件路径被目录占用：{relative}')
        if before is not None:
            if before == after:
                continue
            raise RevisionError(f'新文件已存在且内容不同，拒绝覆盖：{relative}')
        planned.append(dict(path=relative, before=None, after=after))
    return manifest, planned


def atomic_write(target: Path, content: bytes) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    mode = (target.stat().st_mode & 0o777) if target.exists() else 0o644
    temp_name: Optional[str] = None
    try:
        with tempfile.NamedTemporaryFile(dir=target.parent, prefix='.revision-', delete=False) as handle:
            temp_name = handle.name
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temp_name, mode)
        os.replace(temp_name, target)
    finally:
        if temp_name and Path(temp_name).exists():
            Path(temp_name).unlink()


def apply_plan(root: Path, manifest: dict, plan: list[dict]) -> Optional[Path]:
    if not plan:
        return None
    backups_root = checked_path(root, BACKUPS)
    backups_root.mkdir(exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    backup = backups_root / (manifest['revision'] + '-' + stamp)
    backup.mkdir()
    journal = {'root': str(root), 'revision': manifest['revision'], 'files': [], 'complete': False}
    for c in plan:
        if c['before'] is not None:
            saved = checked_path(backup / 'before', c['path'])
            saved.parent.mkdir(parents=True, exist_ok=True)
            saved.write_bytes(c['before'])
        journal['files'].append(dict(path=c['path'], existed=c['before'] is not None,
                                     before_sha256=digest(c['before']) if c['before'] is not None else None,
                                     after_sha256=digest(c['after'])))
    atomic_write(backup / 'journal.json', json.dumps(journal, ensure_ascii=False, indent=2).encode())
    done = []
    try:
        for c in plan:
            target = checked_path(root, c['path'])
            current = target.read_bytes() if target.is_file() else None
            if current != c['before']:
                raise RevisionError(f'检查后目标发生变化，停止：{c["path"]}')
            atomic_write(target, c['after'])
            done.append(c)
        journal['complete'] = True
        atomic_write(backup / 'journal.json', json.dumps(journal, ensure_ascii=False, indent=2).encode())
    except Exception:
        for c in reversed(done):
            target = checked_path(root, c['path'])
            if target.is_file() and target.read_bytes() == c['after']:
                if c['before'] is None:
                    target.unlink()
                else:
                    atomic_write(target, c['before'])
        raise
    return backup


def rollback(root: Path, backup_name: str) -> None:
    backup = Path(backup_name).expanduser().resolve()
    expected_parent = (root / BACKUPS).resolve()
    if not backup.is_relative_to(expected_parent) or backup.is_symlink():
        raise RevisionError('回滚目录必须位于该仓库的 .research-revision-backups 下。')
    journal = json.loads((backup / 'journal.json').read_text(encoding='utf-8'))
    if journal.get('root') != str(root) or not journal.get('complete'):
        raise RevisionError('备份不属于该仓库，或上次应用未完整完成。')
    restores = []
    for entry in journal['files']:
        target = checked_path(root, entry['path'])
        if not target.is_file() or digest(target.read_bytes()) != entry['after_sha256']:
            raise RevisionError(f'应用后文件已改变，拒绝自动回滚：{entry["path"]}')
        before = None
        if entry['existed']:
            before = checked_path(backup / 'before', entry['path']).read_bytes()
            if digest(before) != entry['before_sha256']:
                raise RevisionError(f'备份内容损坏：{entry["path"]}')
        restores.append((target, before))
    for target, before in reversed(restores):
        if before is None:
            target.unlink()
        else:
            atomic_write(target, before)
    journal['rolled_back'] = True
    atomic_write(backup / 'journal.json', json.dumps(journal, ensure_ascii=False, indent=2).encode())
    print(f'已恢复 {len(restores)} 个文件；备份目录保留。')


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('repository', help='本地仓库根目录；不是网址')
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--check', action='store_true', help='只检查；默认行为')
    mode.add_argument('--apply', action='store_true', help='应用修改并保存备份；不提交或推送')
    mode.add_argument('--rollback', metavar='BACKUP', help='回滚到脚本保存的备份，拒绝覆盖后续编辑')
    args = parser.parse_args()
    root = Path(args.repository).expanduser().resolve()
    try:
        if args.rollback:
            rollback(root, args.rollback)
            return 0
        manifest, plan = load_plan(root)
        modified = sum(x['before'] is not None for x in plan)
        print(f'目标仓库：{root}')
        print(f'参考基线提交：{manifest["base_commit"]}（仅供追溯，不强制重置当前分支）')
        print(f'待增补已有文件：{modified}；待新增文件：{len(plan)-modified}')
        for c in plan:
            print(('增补  ' if c['before'] is not None else '新增  ') + c['path'])
        if not args.apply:
            print('检查通过；未修改文件。使用 --apply 才执行。')
            return 0
        backup = apply_plan(root, manifest, plan)
        if backup:
            print(f'已应用 {len(plan)} 个文件；备份：{backup}')
        else:
            print('所有内容已一致，无须再次应用。')
        print('没有运行 git commit、git push 或任何网络请求。')
        return 0
    except (RevisionError, OSError, ValueError, KeyError) as exc:
        print(f'停止：{exc}', file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
