"""Test the local patcher against fixtures, never against a live repository."""
from pathlib import Path
import importlib.util, json, tempfile, hashlib, unittest
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('apply_revision',ROOT/'apply_revision.py')
module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)

class PatchTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.repo=Path(self.tmp.name).resolve()
        self.manifest=json.loads((ROOT/'manifest.json').read_text())
        (self.repo/'AGENTS.md').write_text('# Test project\n\nFixture only.\n')
        for op in self.manifest['operations']:
            p=self.repo/op['path'];p.parent.mkdir(parents=True,exist_ok=True)
            p.write_text('# 测试原文标题\n\n原文不得丢失。\n\n## 原资料\n独立测试内容，不是真实仓库。\n')
        self.original={p.relative_to(self.repo).as_posix():p.read_bytes() for p in self.repo.rglob('*') if p.is_file()}
    def tearDown(self):self.tmp.cleanup()
    def test_dry_run_apply_idempotent_and_rollback(self):
        m,plan=module.load_plan(self.repo)
        self.assertEqual(len(plan),56)
        for rel,raw in self.original.items(): self.assertEqual((self.repo/rel).read_bytes(),raw)
        backup=module.apply_plan(self.repo,m,plan)
        self.assertTrue(backup.exists())
        for op in m['operations']:
            s=(self.repo/op['path']).read_text();self.assertIn('原文不得丢失。',s)
            self.assertEqual(s.count('<!-- BEGIN '+op['block_id']+' -->'),1)
        _,again=module.load_plan(self.repo);self.assertEqual(again,[])
        module.rollback(self.repo,str(backup))
        for rel,raw in self.original.items():self.assertEqual((self.repo/rel).read_bytes(),raw)
        for f in m['new_files']:self.assertFalse((self.repo/f['path']).exists())
    def test_edited_block_refused(self):
        m,plan=module.load_plan(self.repo);module.apply_plan(self.repo,m,plan)
        op=m['operations'][0];p=self.repo/op['path']
        p.write_text(p.read_text().replace('设计取向与第二层比较事实增补','人工修改的增补'))
        with self.assertRaises(module.RevisionError):module.load_plan(self.repo)
    def test_existing_new_file_refused(self):
        f=self.manifest['new_files'][0];p=self.repo/f['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_text('User document')
        with self.assertRaises(module.RevisionError):module.load_plan(self.repo)
    def test_missing_original_refused(self):
        (self.repo/self.manifest['operations'][0]['path']).unlink()
        with self.assertRaises(module.RevisionError):module.load_plan(self.repo)
    def test_path_boundaries(self):
        for p in ['../escape.md','.github/workflows/x.yml','99_归档/change.md','/absolute.md','.git/config']:
            with self.assertRaises(module.RevisionError):module.checked_path(self.repo,p)
        other=self.repo/'redirect';other.symlink_to(Path('/tmp'),target_is_directory=True)
        with self.assertRaises(module.RevisionError):module.checked_path(self.repo,'redirect/file.md')
    def test_crlf_is_preserved(self):
        op=self.manifest['operations'][0];raw='# 原文\r\n\r\n正文保留\r\n'.encode()
        out=module.insert_block(raw,op)
        self.assertTrue(out.endswith(b'\r\n\r\n'+ '正文保留\r\n'.encode()))
        self.assertNotIn(b'\n',out.replace(b'\r\n',b''))
        self.assertEqual(module.insert_block(out,op),out)
    def test_rollback_rejects_subsequent_edit(self):
        m,plan=module.load_plan(self.repo);backup=module.apply_plan(self.repo,m,plan)
        p=self.repo/m['operations'][0]['path'];p.write_text(p.read_text()+'\nNew user edit\n')
        with self.assertRaises(module.RevisionError):module.rollback(self.repo,str(backup))

if __name__=='__main__':unittest.main(verbosity=2)
