"""Validate the bundle's internal consistency, not external source truth."""
from pathlib import Path
import json, hashlib, math
ROOT=Path(__file__).resolve().parents[1]
d=json.loads((ROOT/'payload/芯片调研/比较分析/两层比较数据-20260923.json').read_text())
assert len(d['products'])==40
assert len({p['card_path'] for p in d['products']})==40
assert len(d['groups'])==13
by={p['id']:p for p in d['products']}
assert len(by)==40
records=0
for p in d['products']:
 assert all(r in d['sources'] for r in p['classification_sources'])
 for f in p['facts']:
  assert f['sources'] and all(r in d['sources'] for r in f['sources'])
  records+=1
 m=p['metrics']
 if m and m['peak_tflops']:
  assert math.isclose(m['bandwidth_per_peak_byte_per_flop'],m['bandwidth_gbs']/(m['peak_tflops']*1000))
  if m['dram_gb'] is not None:assert math.isclose(m['capacity_per_peak_gb_per_tflops'],m['dram_gb']/m['peak_tflops'])
for g in d['groups']:
 assert all(id in by for id in g['products'])
 for id in g['products']:assert g['id'] in by[id]['groups']
assert by['asc950pr']['metrics']['peak_tflops'] is None
assert by['asc950dt']['metrics']['peak_tflops'] is None
assert by['s4']['metrics']['dram_gb'] is None
assert by['s8']['metrics']['dram_gb'] is None
assert math.isclose(by['v5e']['metrics']['bandwidth_gbs'],858.9934592)
assert math.isclose(by['v5p']['metrics']['dram_gb'],102.00547328)
assert math.isclose(by['h200n']['metrics']['bandwidth_per_peak_byte_per_flop']/by['h200s']['metrics']['bandwidth_per_peak_byte_per_flop'],989.5/835.5)
m=json.loads((ROOT/'manifest.json').read_text())
assert len(m['operations'])==42 and len(m['new_files'])==14
for f in m['new_files']:
 assert hashlib.sha256((ROOT/'payload'/f['path']).read_bytes()).hexdigest()==f['sha256']
print(f'PASS: 40 unique products, 13 comparison groups, {records} sourced fact records; ratios, missing values, units and payload hashes checked.')
