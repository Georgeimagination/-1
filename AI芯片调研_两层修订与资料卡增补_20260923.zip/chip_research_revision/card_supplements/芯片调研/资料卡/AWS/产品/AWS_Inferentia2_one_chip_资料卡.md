## 2026-09-23：设计取向与第二层比较事实增补

**对象：Inferentia2。** 增补，不改变原卡状态；原有内容与参考资料保留。本节事实用于两层比较，既有正文与本节出现不同值时，应优先查看各自的对象、日期与条件，不静默覆盖。

| 定位字段 | 内容 |
| --- | --- |
| 主要设计取向 | 偏向推理 |
| 阶段/部署目标 | 推理 |
| 官方支持范围 | 官方主推推理，其他用途不作排他判断 |
| 分类依据 | 官方产品目标为生成式AI等推理；共享核心不改变产品定位。 [O03][R19] |
| 对照组 | G03 |

### 本轮保留或补入的事实

| 事实项 | 记录 | 作用域/条件 | 来源 |
| --- | --- | --- | --- |
| 单芯片共同资源 | 2个NeuronCore-v2、2个HBM stack、32个DMA、6个CC-Core；NeuronLink-v2 2组 | 单chip/device；实例聚合资源不下放 | [O03] |
| NCv2工作存储 | 24MiB SBUF + 2MiB PSUM/核；128 partitions，PSUM每partition八bank | 软件管理工作区与累加区；两核相加不是共享L2 | [O03] |
| 共同执行通路 | Tensor/Vector/Scalar/GpSimd各有独立sequencer；Tensor为128×128 PE阵列 | 共享NCv2，不意味着任意引擎并发都无冲突 | [O03] |
| SRAM访问约束 | Vector与GpSimd不能同时访问SBUF；Vector与Scalar不能同时访问PSUM | 接口共享约束，限制可实现的计算/搬运重叠 | [O03] |
| 主存与峰值口径 | HBM 32GiB；820GB/s与820GiB/s官方口径差异保留；逐核BF16约92TFLOPS，整芯片另列190TFLOPS | 92×2与190不是完全相同记录；不要把不同计数边界相加 | [O03][R19] |
| 本轮比较采用的资源值 | FP16/BF16 184 TFLOPS；DRAM 34.359738368 GB；820 GB/s | 逐核矩阵值资源加总；92×2；NKI820GB/s；不改写官方chip190TFLOPS。 | [O03] |

### 本节原始来源与追溯

**[O03]** AWS：Trainium / Inferentia2 NKI Architecture Guide；Device overview；NeuronCore-v2 Compute Engines；memory hierarchy；Data Movement；本轮官方原文复核。[原文](https://awsdocs-neuron.readthedocs-hosted.com/en/latest/nki/guides/architecture/trainium_inferentia2_arch.html)

**[R19]** 仓库产品详解：Inferentia2；产品定位与相应计算、存储、互联章节；沿用文末原始引用；不是本轮全部重新审计；仓库已有资料，本轮使用。[原文](https://github.com/Georgeimagination/-1/blob/abf8c8167b8ccb351c15f8add1cb503692fdcbb0/%E8%8A%AF%E7%89%87%E8%B0%83%E7%A0%94/%E4%BA%A7%E5%93%81%E8%AF%A6%E8%A7%A3/AWS/AWS_Inferentia2_one_chip_%E4%BA%A7%E5%93%81%E8%AF%A6%E8%A7%A3.md)

比较中的百分比、容量假设与性能界属于分析结果，不当作芯片规格；见项目 `芯片调研/比较分析/训练与推理架构比较-两层修订.md`。
