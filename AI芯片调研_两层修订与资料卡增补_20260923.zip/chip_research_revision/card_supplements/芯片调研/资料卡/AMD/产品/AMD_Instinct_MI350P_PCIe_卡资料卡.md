## 2026-09-23：设计取向与第二层比较事实增补

**对象：MI350P 144GB PCIe。** 增补，不改变原卡状态；原有内容与参考资料保留。本节事实用于两层比较，既有正文与本节出现不同值时，应优先查看各自的对象、日期与条件，不静默覆盖。

| 定位字段 | 内容 |
| --- | --- |
| 主要设计取向 | 偏向推理 |
| 阶段/部署目标 | 企业推理部署 |
| 官方支持范围 | 训练、推理；HPC按原产品资料范围 |
| 分类依据 | 已有定位强调企业推理；本轮官方规格复核不等于重新证明独占用途。 [O08][R25] |
| 对照组 | G07 |

### 本轮保留或补入的事实

| 事实项 | 记录 | 作用域/条件 | 来源 |
| --- | --- | --- | --- |
| CDNA4产品资源 | 128 CU；最高引擎频率2.2GHz；LLC 128MB | SKU资源；LLC名称不能代替各层cache组织 | [O08] |
| 功率档位 | 600W最大，另有450W配置 | P的最大功率与X的TBP表头保留；不是负载功耗测量 | [O08] |
| 共同核内机制 | CDNA4每CU LDS 160KB；Matrix:Vector FP16吞吐约16:1；支持MX低精度与结构化稀疏条件路径 | 局部存储与执行机制按原CDNA4资料；不能证明所有模式可同时满速 | [R25][R98] |
| 本轮比较采用的资源值 | FP16/BF16 1150 TFLOPS；DRAM 144 GB；4000 GB/s | 明确矩阵dense；沿用官方网页舍入峰值；不与白皮书更精确时钟换算值混并。 | [O08] |

### 本节原始来源与追溯

**[O08]** AMD：MI350P 官方规格；GPU Specifications；GPU Memory；Requirements；Board Specifications；本轮官方原文复核。[原文](https://www.amd.com/en/support/downloads/drivers.html/accelerators/instinct/instinct-mi350-series/amd-instinct-mi350p.html)

**[R25]** 仓库产品详解：MI350P 144GB PCIe；产品定位与相应计算、存储、互联章节；沿用文末原始引用；不是本轮全部重新审计；仓库已有资料，本轮使用。[原文](https://github.com/Georgeimagination/-1/blob/abf8c8167b8ccb351c15f8add1cb503692fdcbb0/%E8%8A%AF%E7%89%87%E8%B0%83%E7%A0%94/%E4%BA%A7%E5%93%81%E8%AF%A6%E8%A7%A3/AMD/MI350P.md)

**[R98]** 仓库：比较维度与数据支持范围；家族内比较项目与已整理的同族参数；新增复算不等于原始实测；仓库已有资料，本轮读取。[原文](https://github.com/Georgeimagination/-1/blob/abf8c8167b8ccb351c15f8add1cb503692fdcbb0/%E8%8A%AF%E7%89%87%E8%B0%83%E7%A0%94/%E6%AF%94%E8%BE%83%E5%88%86%E6%9E%90/%E6%AF%94%E8%BE%83%E7%BB%B4%E5%BA%A6%E4%B8%8E%E6%95%B0%E6%8D%AE%E6%94%AF%E6%8C%81%E8%8C%83%E5%9B%B4.md)

比较中的百分比、容量假设与性能界属于分析结果，不当作芯片规格；见项目 `芯片调研/比较分析/训练与推理架构比较-两层修订.md`。
