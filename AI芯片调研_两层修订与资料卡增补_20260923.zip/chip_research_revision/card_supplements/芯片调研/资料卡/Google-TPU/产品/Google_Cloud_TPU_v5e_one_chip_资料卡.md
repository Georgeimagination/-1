## 2026-09-23：设计取向与第二层比较事实增补

**对象：TPU v5e。** 增补，不改变原卡状态；原有内容与参考资料保留。本节事实用于两层比较，既有正文与本节出现不同值时，应优先查看各自的对象、日期与条件，不静默覆盖。

| 定位字段 | 内容 |
| --- | --- |
| 主要设计取向 | 训推双重取向 |
| 阶段/部署目标 | 成本效率、训练与serving |
| 官方支持范围 | 训练与推理均有资料；主取向不表示排他能力 |
| 分类依据 | 官方明确定义combined training and inference；e不等于推理专用。 [O05][O07][R12] |
| 对照组 | G06 |

### 本轮保留或补入的事实

| 事实项 | 记录 | 作用域/条件 | 来源 |
| --- | --- | --- | --- |
| TensorCore与MXU | 1 TensorCore/chip；每TensorCore 4 MXU，并含vector/scalar路径 | 芯片核数与每核执行单元分层 | [O05] |
| VMEM软件描述 | 128MiB/TensorCore；整芯片128MiB | JAX表明确per TensorCore；不称统一共享缓存 | [O07] |
| 官方主存记录与差异 | Cloud表16GB、800GiB/s；JAX表17GB、820GB/s | Cloud与软件描述分别保留；800GiB/s=858.9934592GB/s为单位换算，不是820GB/s的同义写法 | [O05][O07] |
| ICI与部署 | 400GB/s双向、4端口、2D torus；同芯片可按training或serving部署 | 部署配置可改变吞吐/可用性/时延取向；不是新的芯片SKU | [O05] |
| 本轮比较采用的资源值 | FP16/BF16 197 TFLOPS；DRAM 16 GB；858.9934592 GB/s | 官方条件值；选Cloud整芯片原表；JAX另一带宽候选不混入。 | [O05][O07] |

### 本节原始来源与追溯

**[O05]** Google Cloud：TPU v5e；System architecture 表；Configurations 的训推部署说明；本轮官方原文复核。[原文](https://docs.cloud.google.com/tpu/docs/v5e)

**[O07]** JAX：TPU Hardware Reference；表前 per TensorCore 注释；V5E、V5P 行及生成代码；软件硬件描述不是同条件实测；本轮官方原文复核。[原文](https://docs.jax.dev/en/latest/pallas/tpu/hardware.html)

**[R12]** 仓库产品详解：TPU v5e；产品定位与相应计算、存储、互联章节；沿用文末原始引用；不是本轮全部重新审计；仓库已有资料，本轮使用。[原文](https://github.com/Georgeimagination/-1/blob/abf8c8167b8ccb351c15f8add1cb503692fdcbb0/%E8%8A%AF%E7%89%87%E8%B0%83%E7%A0%94/%E4%BA%A7%E5%93%81%E8%AF%A6%E8%A7%A3/Google-TPU/Google_Cloud_TPU_v5e_one_chip_%E4%BA%A7%E5%93%81%E8%AF%A6%E8%A7%A3.md)

比较中的百分比、容量假设与性能界属于分析结果，不当作芯片规格；见项目 `芯片调研/比较分析/训练与推理架构比较-两层修订.md`。
