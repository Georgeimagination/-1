## 2026-09-23：设计取向与第二层比较事实增补

**对象：TPU v5p。** 增补，不改变原卡状态；原有内容与参考资料保留。本节事实用于两层比较，既有正文与本节出现不同值时，应优先查看各自的对象、日期与条件，不静默覆盖。

| 定位字段 | 内容 |
| --- | --- |
| 主要设计取向 | 偏向训练 |
| 阶段/部署目标 | 大规模训练与扩展 |
| 官方支持范围 | 训练与推理均有资料；主取向不表示排他能力 |
| 分类依据 | 训练强调与大规模配置；支持范围与主取向分列。 [O06][O07][R13] |
| 对照组 | G06 |

### 本轮保留或补入的事实

| 事实项 | 记录 | 作用域/条件 | 来源 |
| --- | --- | --- | --- |
| TensorCore与MXU | 2 TensorCore/chip；每TensorCore 4 MXU，并含vector/scalar路径 | 芯片核数与每核执行单元分层 | [O06] |
| VMEM软件描述 | 64MiB/TensorCore；两核局部空间算术合计128MiB | JAX表明确per TensorCore；不称统一共享缓存 | [O07] |
| 官方主存记录与差异 | Cloud表95GiB、2765GB/s；JAX每核51GB、1230GB/s | 两核软件带宽合计2460GB/s，与Cloud2765不同；95GiB=102.00547328GB | [O06][O07] |
| ICI与部署 | 1200GB/s双向；4×4×4及更大slice完整3D torus，小于该规模不具完整wrap-around | 芯片端点与系统拓扑区别；8960-chip Pod不等于单作业规模 | [O06] |
| 本轮比较采用的资源值 | FP16/BF16 459 TFLOPS；DRAM 102.00547328 GB；2765 GB/s | 官方条件值；95GiB转为GB；JAX带宽另存。FP8执行条件不由此表单行判定。 | [O06][O07] |

### 本节原始来源与追溯

**[O06]** Google Cloud：TPU v5p；System architecture 表；3D torus 范围脚注；本轮官方原文复核。[原文](https://docs.cloud.google.com/tpu/docs/v5p)

**[O07]** JAX：TPU Hardware Reference；表前 per TensorCore 注释；V5E、V5P 行及生成代码；软件硬件描述不是同条件实测；本轮官方原文复核。[原文](https://docs.jax.dev/en/latest/pallas/tpu/hardware.html)

**[R13]** 仓库产品详解：TPU v5p；产品定位与相应计算、存储、互联章节；沿用文末原始引用；不是本轮全部重新审计；仓库已有资料，本轮使用。[原文](https://github.com/Georgeimagination/-1/blob/abf8c8167b8ccb351c15f8add1cb503692fdcbb0/%E8%8A%AF%E7%89%87%E8%B0%83%E7%A0%94/%E4%BA%A7%E5%93%81%E8%AF%A6%E8%A7%A3/Google-TPU/Google_Cloud_TPU_v5p_one_chip_%E4%BA%A7%E5%93%81%E8%AF%A6%E8%A7%A3.md)

比较中的百分比、容量假设与性能界属于分析结果，不当作芯片规格；见项目 `芯片调研/比较分析/训练与推理架构比较-两层修订.md`。
