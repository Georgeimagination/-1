## 2026-09-23：设计取向与第二层比较事实增补

**对象：TPU 8t。** 增补，不改变原卡状态；原有内容与参考资料保留。本节事实用于两层比较，既有正文与本节出现不同值时，应优先查看各自的对象、日期与条件，不静默覆盖。

| 定位字段 | 内容 |
| --- | --- |
| 主要设计取向 | 偏向训练 |
| 阶段/部署目标 | 大规模预训练 |
| 官方支持范围 | 训练与推理均有资料；主取向不表示排他能力 |
| 分类依据 | 官方将大规模预训练列为首要负载。 [O01][R16] |
| 对照组 | G01 |

### 本轮保留或补入的事实

| 事实项 | 记录 | 作用域/条件 | 来源 |
| --- | --- | --- | --- |
| 公开片上Vmem | 128MB/chip | 官方文章标法；与JAX MiB软件描述分别保留 | [O01][O07] |
| 专用与互联机制 | SparseCore与文章列出的LLM Decoder Engine；3D torus ICI；面向大规模预训练 | 模块职责按官方文章；不把系统资源计入单芯片存储 | [O01] |
| 本轮比较采用的资源值 | FP4 12600 TFLOPS；DRAM 216 GB；6528 GB/s | 同源FP4公布值，条件保留；未作为BF16换算；与其他发布图精度标签冲突仍按原卡保留。 | [O01] |

### 本节原始来源与追溯

**[O01]** Google：TPU 8t / 8i technical deep dive；两款产品取向；at a glance 表；Vmem、CAE、ICI章节；本轮官方原文复核。[原文](https://cloud.google.com/blog/products/compute/tpu-8t-and-tpu-8i-technical-deep-dive)

**[R16]** 仓库产品详解：TPU 8t；产品定位与相应计算、存储、互联章节；沿用文末原始引用；不是本轮全部重新审计；仓库已有资料，本轮使用。[原文](https://github.com/Georgeimagination/-1/blob/abf8c8167b8ccb351c15f8add1cb503692fdcbb0/%E8%8A%AF%E7%89%87%E8%B0%83%E7%A0%94/%E4%BA%A7%E5%93%81%E8%AF%A6%E8%A7%A3/Google-TPU/Google_TPU_8t_one_chip_%E4%BA%A7%E5%93%81%E8%AF%A6%E8%A7%A3.md)

**[O07]** JAX：TPU Hardware Reference；表前 per TensorCore 注释；V5E、V5P 行及生成代码；软件硬件描述不是同条件实测；本轮官方原文复核。[原文](https://docs.jax.dev/en/latest/pallas/tpu/hardware.html)

比较中的百分比、容量假设与性能界属于分析结果，不当作芯片规格；见项目 `芯片调研/比较分析/训练与推理架构比较-两层修订.md`。
